const { dispatchN8NWebhook } = require('../services/webhook.service');

async function testWebhookFormatting() {
  console.log('🧪 Testing Webhook Payload Formatting...');

  const testReassignedPayload = {
    event: 'TASK_REASSIGNED',
    type: 'TASK_REASSIGNED',
    workOrderId: 104,
    jobNumber: 'JOB-2026-4983',
    title: 'Emergency Boiler Repair',
    propertyAddress: '24 Victoria Road, Flat 3B, London',
    scheduledDate: '2026-09-10',
    scheduledTimeSlot: '08:00 - 09:30 AM',
    previousTechnician: {
      id: 1,
      name: 'Mukul Sharma',
      phone: '+447911123456',
      email: 'mukul@nexusfms.co.uk',
    },
    technicianName: 'Mukul Sharma',
    contactPhone: '+447911123456',
    contactEmail: 'mukul@nexusfms.co.uk',
    message: 'Work order #JOB-2026-4983 (Emergency Boiler Repair) at 24 Victoria Road has been reassigned to another technician. You are relieved from this task.',
  };

  const reassignedRes = await dispatchN8NWebhook('TASK_REASSIGNED', testReassignedPayload);
  console.log('✓ TASK_REASSIGNED Webhook dispatch response:', reassignedRes);

  const testAssignedPayload = {
    event: 'TASK_ASSIGNED',
    type: 'TASK_ASSIGNED',
    workOrderId: 104,
    jobNumber: 'JOB-2026-4983',
    title: 'Emergency Boiler Repair',
    propertyAddress: '24 Victoria Road, Flat 3B, London',
    scheduledDate: '2026-09-10',
    scheduledTimeSlot: '08:00 - 09:30 AM',
    technicianName: 'Dave Miller',
    technicianPhone: '+447922234567',
    technicianEmail: 'dave@nexusfms.co.uk',
    contactPhone: '+447922234567',
    contactEmail: 'dave@nexusfms.co.uk',
    actionUrl: 'https://nexus-fms.netlify.app/jobs/104',
    message: 'You have been assigned to Job #JOB-2026-4983: Emergency Boiler Repair at 24 Victoria Road scheduled for 2026-09-10 (08:00 - 09:30 AM). View task: https://nexus-fms.netlify.app/jobs/104',
  };

  const assignedRes = await dispatchN8NWebhook('TASK_ASSIGNED', testAssignedPayload);
  console.log('✓ TASK_ASSIGNED Webhook dispatch response:', assignedRes);

  console.log('🎉 Verification passed successfully!');
  process.exit(0);
}

testWebhookFormatting().catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
