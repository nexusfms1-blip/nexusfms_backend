const axios = require('axios');

async function createLightlab() {
  const urls = [
    'https://nexus-fms-backend-production.up.railway.app/api/v1',
    'https://nexusfmsbackednshrikant-production.up.railway.app/api/v1'
  ];

  for (const baseUrl of urls) {
    console.log('\n--- Creating on:', baseUrl, '---');
    try {
      // 1. Admin login
      const loginRes = await axios.post(`${baseUrl}/auth/login`, {
        email: 'admin@nexusfms.com',
        password: 'Password123!'
      });
      const token = loginRes.data.token;
      console.log('Admin token obtained');

      // 2. Create staff
      const staffRes = await axios.post(`${baseUrl}/staff`, {
        full_name: 'lightlab',
        name: 'lightlab',
        email: 'lightlabcreation@gmail.com',
        password: '123456',
        phone: '987456451212',
        role_title: 'Maintenance Technician',
        workingDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        startTime: '08:00:00',
        endTime: '17:00:00',
        color: '#009bf2'
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log('Staff created:', staffRes.data);

      // 3. Test login immediately with lightlab
      const staffLogin = await axios.post(`${baseUrl}/auth/login`, {
        email: 'lightlabcreation@gmail.com',
        password: '123456'
      });
      console.log('✓ Staff Login SUCCESS on', baseUrl, 'User:', staffLogin.data.user);
    } catch (err) {
      console.log('Error on', baseUrl, err.response?.status, err.response?.data || err.message);
    }
  }
}

createLightlab();
