const axios = require('axios');

async function testDemoLogin() {
  const passwords = ['123456', 'Password123!', 'password123', 'admin', 'password'];
  for (const p of passwords) {
    try {
      const res = await axios.post('https://nexus-fms-backend-production.up.railway.app/api/v1/auth/login', {
        email: 'demo@gmail.com',
        password: p
      });
      console.log(`Success with password: "${p}"!`, res.data.user);
      return;
    } catch (e) {
      console.log(`Failed with password "${p}":`, e.response?.status, e.response?.data?.message);
    }
  }
}

testDemoLogin();
