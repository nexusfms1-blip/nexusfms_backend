require('dotenv').config();
const { pool } = require('../config/db');

async function check() {
  const [wo] = await pool.query('SELECT id, job_number, title, resident_id, resident_name, contact_phone, contact_email, property_address FROM work_orders WHERE id = 224 OR title LIKE "%reapint%"');
  console.log('Work Order:', wo);
  if (wo.length > 0) {
    const [qr] = await pool.query('SELECT * FROM quote_requests WHERE work_order_id = ?', [wo[0].id]);
    console.log('Quote Requests:', qr);
    const [notifs] = await pool.query('SELECT * FROM notifications WHERE related_entity_id = ?', [wo[0].id]);
    console.log('Notifications:', notifs);
    const [del] = await pool.query('SELECT * FROM notification_delivery ORDER BY id DESC LIMIT 10');
    console.log('Recent Notification Delivery:', del);
  }
}

check().then(() => process.exit(0)).catch(e => {
  console.error(e);
  process.exit(1);
});
